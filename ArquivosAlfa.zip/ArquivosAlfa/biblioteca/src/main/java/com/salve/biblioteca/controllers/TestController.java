package com.salve.biblioteca.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class TestController {
    
}
