package com.salve.biblioteca.entities;

import lombok.Data;

@Data
public class CategoriaDoGrupo {
    private Categoria categoria;
    private Grupo grupo;
}
