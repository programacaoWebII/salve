package com.salve.biblioteca.entities;

import lombok.Data;

@Data
public class SubcategoriasDoGrupo {
    private Grupo grupo;
    private Subcategoria subcategoria;
}
